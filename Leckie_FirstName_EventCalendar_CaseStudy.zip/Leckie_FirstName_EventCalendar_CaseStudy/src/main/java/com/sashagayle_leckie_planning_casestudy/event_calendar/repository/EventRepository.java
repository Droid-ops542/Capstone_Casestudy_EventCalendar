package com.sashagayle_leckie_planning_casestudy.event_calendar.repository;

import com.sashagayle_leckie_planning_casestudy.event_calendar.entity.Event;
import com.sashagayle_leckie_planning_casestudy.event_calendar.entity.User;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Date;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    // Find events associated with a specific user
    List<Event> findByUser(User user);

    // Custom query to find events by title (case insensitive)
    @Query("SELECT e FROM Event e WHERE LOWER(e.title) LIKE LOWER(CONCAT('%', :title, '%'))")
    List<Event> findByTitleContaining(@Param("title") String title);

    // Custom query to find events within a specific date range
    @Query("SELECT e FROM Event e WHERE e.eventDate BETWEEN :startDate AND :endDate")
    List<Event> findByDateRange(@Param("startDate") Date startDate, @Param("endDate") Date endDate, Sort sort);

    // Custom query to find events by user and within a date range
    @Query("SELECT e FROM Event e WHERE e.user = :user AND e.eventDate BETWEEN :startDate AND :endDate")
    List<Event> findByUserAndDateRange(@Param("user") User user, @Param("startDate") Date startDate, @Param("endDate") Date endDate, Sort sort);

    // Custom query to find events by user and event type
    @Query("SELECT e FROM Event e WHERE e.user = :user AND e.type = :type")
    List<Event> findByUserAndType(@Param("user") User user, @Param("type") String type);
}
