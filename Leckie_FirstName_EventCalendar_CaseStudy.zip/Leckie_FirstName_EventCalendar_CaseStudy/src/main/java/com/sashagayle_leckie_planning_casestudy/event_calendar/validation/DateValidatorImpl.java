package com.sashagayle_leckie_planning_casestudy.eventcalendar.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateValidatorImpl implements ConstraintValidator<DateValidator, String> {

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    @Override
    public void initialize(DateValidator constraintAnnotation) {

    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isEmpty()) {
            return true;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        dateFormat.setLenient(false); // Disable lenient parsing

        try {
            dateFormat.parse(value);
            return true; // Valid date format
        } catch (ParseException e) {
            return false; // Invalid date format
        }
    }
}
