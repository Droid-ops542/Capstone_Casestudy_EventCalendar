package com.sashagayle_leckie_planning_casestudy.event_calendar.controller;

import com.sashagayle_leckie_planning_casestudy.event_calendar.entity.Event;
import com.sashagayle_leckie_planning_casestudy.event_calendar.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class EventController {

    @Autowired
    private EventService eventService;

    // Display home page with upcoming events
    @GetMapping("/home")
    public String showHomePage(Model model) {
        List<Event> events = eventService.getAllEvents();
        model.addAttribute("events", events);  // Adding events to model for Thymeleaf
        return "home";  // "home" corresponds to home.html in templates folder
    }

    // Display lesson details
    @GetMapping("/lesson-details")
    public String showLessonDetails(Model model) {
        // Add logic to fetch lesson details
        return "lesson-details";  // "lesson-details" corresponds to lesson-details.html
    }

    // Display sign-up page
    @GetMapping("/sign-up")
    public String showSignUpPage() {
        return "sign-up";  // "sign-up" corresponds to sign-up.html
    }

    // Display user profile page
    @GetMapping("/profile")
    public String showProfilePage() {
        return "profile";  // "profile" corresponds to profile.html
    }

    // Display login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";  // "login" corresponds to login.html
    }

    // Display registration confirmation page
    @GetMapping("/confirmation")
    public String showConfirmationPage() {
        return "confirmation";  // "confirmation" corresponds to confirmation.html
    }
}
