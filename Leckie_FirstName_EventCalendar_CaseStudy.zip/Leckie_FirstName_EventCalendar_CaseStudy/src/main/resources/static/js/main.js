document.addEventListener("DOMContentLoaded", function () {

  // Handle form validation for registration and login forms
  const registrationForm = document.getElementById("registration-form");
  const loginForm = document.getElementById("login-form");

  if (registrationForm) {
    registrationForm.addEventListener("submit", function (e) {
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;

      // Email validation
      if (!validateEmail(email)) {
        e.preventDefault();
        alert("Please enter a valid email address.");
      }
      // Password validation
      else if (password.length < 6) {
        e.preventDefault();
        alert("Password must be at least 6 characters.");
      }
    });
  }

  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      const email = document.getElementById("login-email").value;
      const password = document.getElementById("login-password").value;

      // Email validation for login
      if (!validateEmail(email)) {
        e.preventDefault();
        alert("Please enter a valid email address.");
      }
      // Password validation for login
      else if (password.length < 6) {
        e.preventDefault();
        alert("Password must be at least 6 characters.");
      }
    });
  }

  // Smooth scroll for internal links (e.g., navigation links)
  const internalLinks = document.querySelectorAll('a[href^="#"]');
  internalLinks.forEach(function (link) {
    link.addEventListener("click", function (e) {
      e.preventDefault();
      const targetId = this.getAttribute("href").substring(1);
      const targetElement = document.getElementById(targetId);
      targetElement.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  });

  // Parallax effect (assuming you are using the parallax.js library)
  const parallaxElements = document.querySelectorAll(".parallax-window");
  if (parallaxElements.length > 0) {
    parallaxElements.forEach((el) => {
      el.addEventListener("scroll", function () {
        // Implement parallax scroll logic if using a library or custom logic
      });
    });
  }

  // Manage confirmation message visibility on the registration confirmation page
  const confirmationMessage = document.getElementById("confirmationMessage");
  if (confirmationMessage) {
    setTimeout(() => {
      confirmationMessage.style.display = "none"; // Hide after 5 seconds
    }, 5000);
  }

  // Function to validate email format
  function validateEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return re.test(email);
  }

  // Initialize parallax effect for elements with the 'parallax' class
  const parallaxElements = document.querySelectorAll(".parallax");
  if (parallaxElements.length > 0) {
    parallaxElements.forEach(function (el) {
      let offset = el.offsetTop;
      window.addEventListener("scroll", function () {
        let scrollPos = window.scrollY;
        el.style.transform = "translateY(" + (scrollPos * 0.5) + "px)";
      });
    });
  }

});
